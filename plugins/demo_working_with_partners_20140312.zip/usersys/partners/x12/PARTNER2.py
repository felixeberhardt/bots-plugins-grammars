syntax = {
    'add_crlfafterrecord_sep':'\r\n',
    'field_sep':'+',
    'record_sep':"'",
    'sfield_sep':':',
    'ISA05':'ZZ',
    'ISA07':'ZZ',
    }
