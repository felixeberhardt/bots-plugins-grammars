
syntax = { 
        'charset':   'utf-8' ,
        'template':   'orders2print.html',			#template (kid-file) to use
        'envelope-template':   'orders2printenvelope.html',			#template (kid-file) to use
        'merge':		True,
       }
