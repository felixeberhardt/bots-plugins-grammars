from bots.botsconfig import *
from records_9 import recorddefs
from tradacomssyntax import syntax

structure = [
{ID:'MHD',MIN:1,MAX:1,LEVEL:[
    {ID:'OFT',MIN:1,MAX:1},
    {ID:'MTR',MIN:1,MAX:1},
    ]
}]
