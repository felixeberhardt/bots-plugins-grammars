syntax = { 
        'checkcharsetout'   :   'ignore',
        }
