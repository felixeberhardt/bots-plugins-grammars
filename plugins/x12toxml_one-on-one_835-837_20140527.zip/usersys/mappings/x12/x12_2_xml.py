#mapping-script
import bots.transform as transform

def main(inn,out):
    transform.inn2out(inn,out)  #receive ISA; send out as xml_nocheck
