from bots.botsconfig import *
from base837005010 import syntax
from base837005010 import structure
from records005010 import recorddefs
