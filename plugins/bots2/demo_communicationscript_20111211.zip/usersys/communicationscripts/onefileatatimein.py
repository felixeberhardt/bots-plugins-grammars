import os
import glob
import shutil

def connect(channeldict):
    print '\n\nconnect',channeldict['idchannel']

def main(channeldict):
    print 'main',channeldict['idchannel']
    #copies the edi files from an existing dir to the dir where bots picks them up....just testing
    for filename in glob.glob('botssys/infile/demo_comscript/source/*'):
        print 'sends:', filename
        yield filename

def disconnect(channeldict):
    print 'disconnect',channeldict['idchannel']
