
def filename(channeldict,filename,ta_from=None,**argv):
    ''' Change the filename for the outgoing file.
        Receive the default bots filename, information about the channel and the current entry in ta table.
        Returned is the new filename.
        Be aware: filenames are supposed to be unique eg for file, ftp.
        Advise: use the filename as bots made this in your own filename.
    '''
    return 'XX' + filename       #place XX before the filename