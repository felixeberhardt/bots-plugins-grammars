import bots.transform as transform
from bots.botsconfig import *

def main(routedict):
    transform.run(idchannel=routedict['fromchannel'],idroute=routedict['idroute'])
    transform.addinfo(where={'status':FILEIN, 'fromchannel':routedict['fromchannel'],'idroute':routedict['idroute']},
                        change={'status':FILEOUT,'tochannel':routedict['tochannel']})
    transform.run(idchannel=routedict['tochannel'],idroute=routedict['idroute'])

