#~ only use because plugin does not create empty directories
