#mapping-script
import copy

def main(inn,out):
    out.root = copy.deepcopy(inn.root)
