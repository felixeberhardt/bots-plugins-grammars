from bots.botsconfig import *

syntax = { 
        'merge': False,
        'flattenxml': True,
        }
