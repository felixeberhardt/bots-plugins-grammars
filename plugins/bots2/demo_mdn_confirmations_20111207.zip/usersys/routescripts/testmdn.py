import bots.transform as transform
from bots.botsconfig import *

def postincommunication(routedict):
    if routedict['seq'] in [21,31]:      #incoming MDN are set to DONE: stop processing them.
        transform.changestatustinfo(change=DONE,
                                    where={'statust':OK,'status':FILEIN,'idroute':routedict['idroute']})
    elif routedict['seq'] in [11]:    #(passthrough) change status of incoming files to outgoing (do not translate)
        transform.addinfo(change={'status':MERGED},
                            where={'status':FILEIN,'idroute':routedict['idroute']})

