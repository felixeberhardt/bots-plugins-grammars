#mapping-script
import bots.transform as transform

def main(inn,out):
    transform.inn2out(inn,out)
    out.ta_info['frompartner'] = 'FROM PARTNER'   #only a demo
    out.ta_info['topartner'] = 'TO PARTNER'   #only a demo
