syntax = { 
        'version'    :  '3',	    #for outgong: value to use in UNB
        'envelope'   :  'edifact',	#for outgoing edifact-messages: this is the envelope to use in merge()
        'checkcharsetout'   :   'ignore',
        }
