
syntax = { 
        'charset':   'utf-8' ,
        'template':   'orders2print.kid',			#template (kid-file) to use
        'envelope-template':   'orders2printenvelope.kid',			#template (kid-file) to use
        'merge':		True,
        'envelope'   :  'orders2printenvelope',	#envelope to use 
       }
